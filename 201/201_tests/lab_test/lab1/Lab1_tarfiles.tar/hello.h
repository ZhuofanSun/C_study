/*
 * A sample C header file for use during the tar presentation.
 *
 * Will not work for Assignments.
 *
 */

#ifndef HELLO_H
#define HELLO_H

/* normally, header file info. goes here */

#endif
